create table users(
  uid serial primary key,
  username text not null,
  email text not null,
  password text not null) without oids;
